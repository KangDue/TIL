T = int(input())
# 여러개의 테스트 케이스가 주어지므로, 각각을 처리합니다.
def mul(a,b):
    return a*b

def sup(a,b):
    sub = []
    la,lb = len(a), len(b)
    comp = la - lb
    if comp >= 0: # la - lb + 1
    	for i in range(comp + 1):
            sub.append( sum(map(mul,a[i:i+lb],b)) )
    else:
        for i in range(-comp + 1):
            sub.append( sum(map(mul,a,b[i:i+la])) )
    return max(sub)

for i in range(T):
    n, m = map(int,input().split())
    aj = list(map(int,input().split()))
    bj = list(map(int,input().split()))
    print("#",i+1," ",sup(aj,bj),sep="")