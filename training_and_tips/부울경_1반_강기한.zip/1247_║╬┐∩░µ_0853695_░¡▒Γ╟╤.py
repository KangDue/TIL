import itertools as it
def l1_dist(a,b):
  return abs(a[0]-b[0])+abs(a[1]-b[1])

T = int(input())
for t in range(1,T+1): 
  n = int(input())
  info = list(map(int,input().split()))
  graph = dict({i:{} for i in range(n+2)})
  info_arr=[]
  for i in range(len(info)//2):
    info_arr.append([info[2*i],info[2*i+1]]) #회사,집, 고객s
  for i in range(n+2):
    for k in range(n+2):
      graph[i].update({k:l1_dist(info_arr[i],info_arr[k])})
  #무조건 0 출발, 1도착입니다. 중간에 다지나고 
  mind=100000
  for path in it.permutations(range(2,n+2)):
    tot = 0 # 거리 초기화
    tot += graph[0][path[0]] #회사 -> 고객1
    for k in range(n-1): #고객 -> 고객
      tot += graph[ path[k] ][ path[k+1] ]
    tot += graph[ path[n-1] ][ 1 ] #마지막 고객 -> 집
    if mind > tot:
      mind = tot
  print("#{}".format(t),mind)