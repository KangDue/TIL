def diagr(a,n):
    new = []
    for i in range(n):
        temp=[]
        for k in range(n):
            temp.append(a[k][i])
        new.append(temp)
    return new

def check(a,m):
  new=""
  for i in a:
    new += str(i)  
  new = new.split("0")
  new = [len(j) for j in new]
  return new.count(m)
      
    
T = int(input())
# 여러개의 테스트 케이스가 주어지므로, 각각을 처리합니다.
for i in range(T):
    n, m = map(int,input().split())
    mat = []
    for z in range(n):
     	mat.append( list(map(int,input().split())) )
    tot = 0
    for j in mat:
    	tot += check(j,m)
    for k in diagr(mat,n):
        tot += check(k,m)
    print("#",i+1," ",tot,sep="")