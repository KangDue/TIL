n = int(input())
for i in range(n): #케이스 수
    m = int(input())
    info = []
    text = ""
    for k in range(m): #압축정보
        info.append( input().split() )
    for  a,b in info:
        text += a*int(b)
    lines, extra = len(text)//10, len(text)%10
    if extra !=0:
        lines += 1
    print("#",i+1,sep="")
    for c in range(lines):
        print(text[c*10:c*10+10])