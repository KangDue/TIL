dir = {0:1,1:2,2:3,3:0} #방향 절대좌표기준 위 왼쪽 아래 오른쪽 ()
rdir = {0:3,3:2,2:1,1:0} #반대로 돌리기

def step(pos):
  global mat
  if pos[2] == 0: #위를 바라볼때
    if (mat[pos[0]][pos[1]+1] == 1) and (mat[pos[0]-1][pos[1]] != 1): #오른쪽이 벽이고 앞이 벽이아니면 앞으로
      pos[0] -= 1
    elif (mat[pos[0]][pos[1]+1] == 1) and (mat[pos[0]-1][pos[1]] == 1): #오른쪽이 벽인데 앞도 벽이면
      pos[2] = dir[pos[2]] #왼쪽으로 턴
    else: #오른쪽이 벽이아니면
      pos[2] = rdir[pos[2]]#오른쪽으로 빠지고
      pos[1] += 1 #오른쪽으로 회전
  elif pos[2] == 1: #왼쪽을 바라볼때
    if (mat[pos[0]-1][pos[1]]==1) and (mat[pos[0]][pos[1]-1] != 1): #오른쪽이 벽이고 앞이 벽이아니면 ㄱ
      pos[1] -= 1
    elif (mat[pos[0]-1][pos[1]]==1) and (mat[pos[0]][pos[1]-1] == 1) : #오른쪽이 벽인데 앞도 벽이면
      pos[2] = dir[pos[2]] #왼쪽으로 턴
    else: #오른쪽이 벽이아니면
      pos[2] = rdir[pos[2]]
      pos[0] -= 1 
  elif pos[2] == 2: #아래를 바라볼때
    if (mat[pos[0]][pos[1]-1]==1) and (mat[pos[0]+1][pos[1]] != 1): #오른쪽이 벽이고 앞이 벽이아니면 ㄱ
      pos[0] += 1
    elif (mat[pos[0]][pos[1]-1]==1) and (mat[pos[0]+1][pos[1]] == 1) : #오른쪽이 벽인데 앞도 벽이면
      pos[2] = dir[pos[2]] #왼쪽으로 턴
    else: #오른쪽이 벽이아니면
      pos[2] = rdir[pos[2]]
      pos[1] -= 1 
  elif pos[2] == 3: #오른쪽을 바라볼때
    if (mat[pos[0]+1][pos[1]] == 1) and (mat[pos[0]][pos[1]+1] != 1): #오른쪽이 벽이고 앞이 벽이아니면 ㄱ
      pos[1] += 1
    elif (mat[pos[0]+1][pos[1]] == 1) and (mat[pos[0]][pos[1]+1] == 1) : #오른쪽이 벽인데 앞도 벽이면
      pos[2] = dir[pos[2]] #왼쪽으로 턴
    else: #오른쪽이 벽이아니면
      pos[2] = rdir[pos[2]]
      pos[0] += 1
  return pos

for tc in range(1,11): #case 10개
    # ////////첫 한걸음
    n = int(input())
    mat = [ input() for i in range(16)]
    mat = [list(map(int,i)) for i in mat]
    for a in range(16):
      for b in range(16):
        if mat[a][b]==2:
          positions=[[a,b,c] for c in range(4)] #모든 방향을 시작점으로 보고 돌려본다. 
          break    
   
    prob = []
    for k in positions:
      pos = k
      pos = step(pos)    
      while mat[pos[0]][pos[1]]<1: #길찾기 시작
        pos = step(pos)
      prob.append(mat[pos[0]][pos[1]])
    if 3 in prob:
      print("#{}".format(tc),1)
    else:
      print("#{}".format(tc),0)