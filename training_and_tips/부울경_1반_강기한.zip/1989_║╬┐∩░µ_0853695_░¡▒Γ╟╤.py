n = int(input())
for i in range(1,n+1):
	word  = list(input())
	word_o = word.copy()
	word.reverse()
	if word == word_o:
		print("#",i," ",1,sep="")
	else:
		print("#",i," ",0,sep="")