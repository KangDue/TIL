def rot_print(a,n):
  for i in range(n):
    for k in range(n): # 90도
      print(a[-1-k][i],end="")
    print(" ",end="")
    for k in range(n): # 180도
      print(a[-1-i][-1-k],end="")
    print(" ",end="")
    for k in range(n): # 270도
      print(a[k][-1-i],end="")
    print("")
    
T = int(input())
# 여러개의 테스트 케이스가 주어지므로, 각각을 처리합니다.
for q in range(1, T + 1):
    n = int(input())
    mat = [ list(map(int,input().split())) for i in range(n)]
    print("#",q,sep="")
    rot_print(mat,n)