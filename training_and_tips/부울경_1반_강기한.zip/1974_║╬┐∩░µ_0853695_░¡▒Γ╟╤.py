T = int(input())
# 여러개의 테스트 케이스가 주어지므로, 각각을 처리합니다.
for q in range(1, T + 1):
  sudoku = [ list(map(int,input().split())) for i in range(9) ]
  for i in range(9):# 행 확인
    temp = list(set(sudoku[i]))
    if len(temp) != 9:
      irow=0
      break
    irow=1
  for i in range(9):# 열 확인
    temp = list(set([sudoku[k][i] for k in range(9)]))
    if len(temp) != 9:
      icol=0
      break
    icol=1
  boxes = []
  for i in range(3):# 3x3 씩 확인
    for k in range(3):
      temp = list(set(sudoku[i*3][k*3:k*3+3]+sudoku[i*3+1][k*3:k*3+3]+sudoku[i*3+2][k*3:k*3+3]))
      if len(temp) != 9:
        boxes.append([0])
  if len(boxes) == 0:
    ibox = 1
  else:
    ibox = 0
  
  if (irow+icol+ibox)==3:
    print("#",q," ",1,sep="")
  else:
    print("#",q," ",0,sep="")