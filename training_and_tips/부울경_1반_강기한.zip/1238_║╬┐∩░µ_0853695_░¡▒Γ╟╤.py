import heapq
def dijkstra(graph, start):
  dist = {node: float('inf') for node in graph} 
  dist[start] = 0 # 시작노드 제외 전부 inf로 초기화.
  que = []
  heapq.heappush(que, [dist[start], start])  # 시작 노드부터 탐색 시작 하기 위함.초기값 설정
 
  while que:  # queue에 남아 있는 노드가 없으면 끝
    cur_dist, cur_dest = heapq.heappop(que)  # 탐색 할 노드, 거리를 가져옴.
                                                                # 현재노드와 연결된 노드 값을 가져옴
      #초기값 -start = 0, 나머지 inf,  so 0<0 False
    if dist[cur_dest] < cur_dist:  # 기존에 있는 거리보다 길다면, 볼 필요도 없음
      continue
     
       
    for new_dest, new_dist in graph[cur_dest].items(): #연결된 노드 중에서
      cost = cur_dist + new_dist  # 해당 노드를 거쳐 갈 때 거리
      if cost < dist[new_dest]:  # 알고 있는 거리 보다 작으면 갱신
        dist[new_dest] = cost
        heapq.heappush(que, [cost, new_dest])  # 다음 인접 거리를 계산 하기 위해 큐에 삽입
     
  return dist
 
for t in range(1,11):
  n, start = map(int,input().split())
  info = list(map(int,input().split()))
  graph = dict({})
  for i in set(info):
    graph[i]={}
  for i in range(len(info)//2):
    graph[info[2*i]].update({info[2*i+1]:1})
  result = dijkstra(graph, start)
   
  candi = []
  for k,v in result.items():
    if type(v) == int:
      candi.append([k,v])
  mv = 0
  for i in candi:
    if mv <= i[1]:
      mv = i[1]
  temp = list(filter(lambda x: x[1] == mv, candi))
  print("#{}".format(t),max(temp)[0])