a, b = map(int, input().split())
c = (a-b)
if c ==1:
	print("A")
elif c==-1:
	print("B")
elif c==2:
	print("B")
else:
	print("A")