a = input()
print(sum(map(int,a)))