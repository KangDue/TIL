class node(object):
  def __init__(self,value):
    self.value = value
    self.parent = 0
    self.child = []
def check(x): #sub tree 크기 체크
  temp = x.child
  count = 1
  if temp == []:
    return 1
  for i in range(len(temp)):
    count += check(temp[i])
  return count

T = int(input())
# 여러개의 테스트 케이스가 주어지므로, 각각을 처리합니다.
for t in range(1, T + 1):
    v, e, a, b = map(int,input().split())
    nodes = list(map(int,input().split()))
    graph = dict({i:node(i) for i in set(nodes) })
    btree = []
    for i in range(e):
      btree.append([ nodes[2*i] , nodes[2*i+1] ])
    for i in range(e):
      graph[btree[i][0]].child.append( graph[btree[i][1]] )
      graph[btree[i][1]].parent = graph[btree[i][0]]

    pa = [graph[a].parent.value]#a조상
    while 1:
      temp = pa[-1]
      try:
        pa.append(graph[temp].parent.value)
      except:
        break
    pb = [graph[b].parent.value] #b 조상
    while 1:
      temp = pb[-1]
      try:
        pb.append(graph[temp].parent.value)
      except:
        break
    for i in pa:
      for k in pb:
        if i == k:
          break
      if i == k:
        sp = i #공통조상
        break
    print("#{}".format(t),sp,check(graph[sp]))