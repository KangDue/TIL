def mat_to_graph(x,option = 0): #직사각 행렬을 graph로 변환
  #option = 0 이면 상하좌우로만 이동, 1이면 대각선도 이동가능
  row = len(x) #행의 수
  col = len(x[0])#열의 수

  boundary = dict({'U':list(range(0,col))[1:-1],'D':list(range( (row-1)*col, row*col)[1:-1]),
                       'L':[col*i for i in range(row)][1:-1], 'R':[col*i-1 for i in range(1,row+1)][1:-1],
                 0:0, 1:col-1, 2:(row-1)*col ,3:row*col-1})
  
  graph = dict({i:{} for i in range(row*col)}) # 모든 노드의 정보를 담을 그래프 생성
  #x flatten 작업
  fx = []
  for i in range(row):
    for k in range(col):
      fx.append(x[i][k])
  x = fx.copy()
  del fx
  #x로부터 가중치를 받아와야함
  if option == 0:
    for i in range(row): # for option 0 대각이동 불가
      for k in range(col):
        ar = dict({0:(i-1)*col+k, 1:(i+1)*col+k,2:i*col+k-1, 3:i*col+k+1}) # 0,1,2,3 = 위 아래 왼쪽 오른쪽
        if i*col+k in boundary['U']:
          graph[i*col+k].update({ar[1]:x[ar[1]], ar[2]:x[ar[2]], ar[3]:x[ar[3]] })
        elif i*col+k in boundary['D']:
          graph[i*col+k].update({ar[0]:x[ar[0]], ar[2]:x[ar[2]], ar[3]:x[ar[3]] })
        elif i*col+k in boundary['L']:
          graph[i*col+k].update({ar[0]:x[ar[0]], ar[1]:x[ar[1]], ar[3]:x[ar[3]] })
        elif i*col+k in boundary['R']:
          graph[i*col+k].update({ar[0]:x[ar[0]], ar[1]:x[ar[1]], ar[2]:x[ar[2]] })
        elif i*col+k == boundary[0]:
          graph[i*col+k].update({ar[1]:x[ar[1]] ,ar[3]:x[ar[3]] })
        elif i*col+k == boundary[1]:
          graph[i*col+k].update({ar[1]:x[ar[1]], ar[2]:x[ar[2]] })
        elif i*col+k == boundary[2]:
          graph[i*col+k].update({ar[0]:x[ar[0]], ar[3]:x[ar[3]] })
        elif i*col+k == boundary[3]:
          graph[i*col+k].update({ar[0]:x[ar[0]], ar[2]:x[ar[2]] })
        else:
          graph[i*col+k].update({ar[0]:x[ar[0]], ar[1]:x[ar[1]] ,ar[2]:x[ar[2]], ar[3]:x[ar[3]] })
    return graph
  if option == 1:
    for i in range(row): # for option 1 대각이동 가능
      for k in range(col):
        ar = dict({0:(i-1)*col+k, 1:(i+1)*col+k,2:i*col+k-1, 3:i*col+k+1,
                  4:(i-1)*col+k-1 ,5:(i-1)*col+k+1 ,6:(i+1)*col+k-1 , 7:(i+1)*col+k+1}) 
        # 0,1,2,3 = 위 아래 왼쪽 오른쪽/ 4,5,6,7: 상좌,상우,하좌,하우
        if i*col+k in boundary['U']:
          graph[i*col+k].update({ar[1]:x[ar[1]], ar[2]:x[ar[2]], ar[3]:x[ar[3]], ar[6]:x[ar[6]], ar[7]:x[ar[7]] })
        elif i*col+k in boundary['D']:
          graph[i*col+k].update({ar[0]:x[ar[0]] ,ar[2]:x[ar[2]], ar[3]:x[ar[3]], ar[4]:x[ar[4]], ar[5]:x[ar[5]] })
        elif i*col+k in boundary['L']:
          graph[i*col+k].update({ar[0]:x[ar[0]] ,ar[1]:x[ar[1]] ,ar[3]:x[ar[3]] ,ar[5]:x[ar[5]] ,ar[7]:x[ar[7]] })
        elif i*col+k in boundary['R']:
          graph[i*col+k].update({ar[0]:x[ar[0]] ,ar[1]:x[ar[1]] ,ar[2]:x[ar[2]] ,ar[4]:x[ar[4]], ar[6]:x[ar[6]] })
        elif i*col+k == boundary[0]:
          graph[i*col+k].update({ar[1]:x[ar[1]] ,ar[3]:x[ar[3]] ,ar[7]:x[ar[7]] })
        elif i*col+k == boundary[1]:
          graph[i*col+k].update({ar[1]:x[ar[1]] ,ar[2]:x[ar[2]] ,ar[6]:x[ar[6]] })
        elif i*col+k == boundary[2]:
          graph[i*col+k].update({ar[0]:x[ar[0]] ,ar[3]:x[ar[3]] ,ar[5]:x[ar[5]] })
        elif i*col+k == boundary[3]:
          graph[i*col+k].update({ar[0]:x[ar[0]] ,ar[2]:x[ar[2]] ,ar[4]:x[ar[4]] })
        else:
          graph[i*col+k].update({ar[0]:x[ar[0]], ar[1]:x[ar[1]], ar[2]:x[ar[2]] ,ar[3]:x[ar[3]] ,ar[4]:x[ar[4]],
                                  ar[5]:x[ar[5]] ,ar[6]:x[ar[6]], ar[7]:x[ar[7]] })
    return graph

import heapq  # 우선순위 큐 구현을 위함
              # 완전 이진트리 부모 vs 자식 노드값만을 비교함. max 또는 min heap + queue
              # 여기선 최소거리 찾아야 하니까 min heap
def dijkstra(graph, start):
  dist = {node: float('inf') for node in graph} 
  dist[start] = 0 # 시작노드 제외 전부 inf로 초기화.
  que = []
  heapq.heappush(que, [dist[start], start])  # 시작 노드부터 탐색 시작 하기 위함.초기값 설정

  while que:  # queue에 남아 있는 노드가 없으면 끝
    cur_dist, cur_dest = heapq.heappop(que)  # 탐색 할 노드, 거리를 가져옴.
                                                                # 현재노드와 연결된 노드 값을 가져옴
      #초기값 -start = 0, 나머지 inf,  so 0<0 False
    if dist[cur_dest] < cur_dist:  # 기존에 있는 거리보다 길다면, 볼 필요도 없음
      continue
    
      
    for new_dest, new_dist in graph[cur_dest].items(): #연결된 노드 중에서
      cost = cur_dist + new_dist  # 해당 노드를 거쳐 갈 때 거리
      if cost < dist[new_dest]:  # 알고 있는 거리 보다 작으면 갱신
        dist[new_dest] = cost
        heapq.heappush(que, [cost, new_dest])  # 다음 인접 거리를 계산 하기 위해 큐에 삽입
    
  return dist

T = int(input())
for i in range(1,T+1):
  n = int(input())
  mat = [ input() for _ in range(n)]
  mat = [list(map(int,_)) for _ in mat]
  graph=mat_to_graph(mat,0)
  print("#{}".format(i),dijkstra(graph, 0)[n*n-1])