<template>
  <div id="app">
    <h1>App</h1>
    <input type="text" v-model.number="appData">
    <p>parentData: {{ parentData }}</p>
    <p>childData: {{ childData }}</p>
    <AppParent :appData="appData" :childData="childData" @getParentData="getParentData"/>
    <AppChild :appData="appData" :parentData="parentData" @getChildData="getChildData"/>
  </div>

</template>

<script>
import AppParent from '@/components/AppParent'
import AppChild from '@/components/AppChild'
export default {
  name:'App',
  components:{
    AppParent,
    AppChild,
  },
  data() {
    return {
      parentData:null,
      childData:null,
      appData:null,
    }
  },
  methods:{
    getChildData(x){
      this.childData = x
    },
    getParentData(x){
      this.parentData = x
    }
  }
}
</script>

<style>
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
}

nav {
  padding: 30px;
}

nav a {
  font-weight: bold;
  color: #2c3e50;
}

nav a.router-link-exact-active {
  color: #42b983;
}
</style>
