<template>
  <div>
    <h1>AppChild</h1>
    <input type="text" v-model.number="childData" @input="toApp">
    <p>appData: {{ appData }}</p>
    <p>parentData: {{ parentData }}</p>
    <p>childData: {{ childData }}</p>
  </div>
</template>

<script>
export default {
  name:'AppChild',
  props:{
    'appData':{
      type:Number,
      default:null
    },
    'parentData':{
          type:Number,
          default:null
        },
 },
  data() {
    return {
      childData:null
    }
  },
  methods:{
    toApp() {
      this.$emit('getChildData',this.childData)
    }
  }
}
</script>

<style>

</style>