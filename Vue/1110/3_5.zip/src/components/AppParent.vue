<template>
  <div>
    <h1>AppParnet</h1>
    <input type="text" v-model.number="parentData" @input="toApp">
    <p>appData: {{ appData }}</p>
    <p>childData: {{ childData }}</p>
  </div>
</template>

<script>
export default {
  name:'AppParent',
  props:{
    'appData':{
      type:Number,
      default:null,
    },
    'childData':{
      type:Number,
      default:null,
    }
  },
  data() {
    return {
      parentData:null,
    }
  },
  methods:{
    toApp() {
      console.log(this.parentData)
      this.$emit('getParentData',this.parentData)
    }
  }
}
</script>

<style>

</style>