<template>
  <div>
    <ul>
      <li v-for="todo in todos" :key="todo.id">
        <span 
          @click="updateTodoStatus(todo)" 
          :class="{ 'is-completed': todo.is_completed }"
        >
        {{ todo.title }}
        </span>
        <button @click="deleteTodo(todo)" class="todo-btn">X</button>
      </li>
    </ul>
    <button @click="getTodos">Get Todos</button>
    <button @click="test">test naver.com</button>
  </div>
</template>

<script>
import axios from 'axios'

export default {
  name: 'TodoList',
  data: function () {
    return {
      todos: null,
      testData:null,
    }
  },
  methods: {
    getTodos: function () {
      axios({
        method: 'get',
        url: 'http://127.0.0.1:8000/todos/',
      })
        .then(res => {
          console.log(res)
          console.log(res.data)
          this.todos = res.data
        })
        .catch(err => {
          console.log(err)
        })
    },
    deleteTodo: function (todo) { //id, title, is_completed 가지고 있음.
      // 3번 문제
        axios({
          url:`http://127.0.0.1:8000/todos/${todo.id}/` ,
          method:'DELETE',
        })
        .then(response => {
          console.log("todo 삭제완료",response)
          this.todos.forEach((val,idx) => {
            if (val==todo) {
              this.todos.splice(idx,1)
              return 0
            }
          })
        })
        .catch(response => {
          console.log("요청 실패",response)
        })
      console.log(todo)
    },
    updateTodoStatus: function (todo) {
      // 4번 문제
        axios.put(`http://127.0.0.1:8000/todos/${todo.id}/`,
          {
            'id':todo.id,
            'title':todo.title,
            'is_completed':!todo.is_completed
        })
        .then(response => {
          console.log("todo 수정완료",response)
          this.todos.forEach((val,idx) => {
            if (val==todo) {
              // this.todos[idx].title = response.data.title
              this.todos[idx].is_completed = response.data.is_completed
              return 0
            }
          })
        })
        .catch(response => {
          console.log("실패")
          console.log(response)
        })
      console.log(todo)
    },
    // VUE_APP_CALL_MY_NAME
    test()
        {console.log(process)
        this.testData = process.env
        console.log(this.testData)
        } 

  },
}
</script>

<style scoped>
  .todo-btn {
    margin-left: 10px;
  }

  .is-completed {
    text-decoration: line-through;
    color: rgb(112, 112, 112);
  }
</style>
