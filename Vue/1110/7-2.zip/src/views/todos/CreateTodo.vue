<template>
  <div>
    <input 
      type="text" 
      v-model.trim="title" 
      @keyup.enter="createTodo"
    >
    <button @click="createTodo">+</button>
  </div>
</template>

<script>
import axios from'axios'

export default {
  name: 'CreateTodo',
  data: function () {
    return {
      title: null,
    }
  },
  methods: {
    createTodo: function () {
      // 2번 문제
      if (this.title) {
        axios({
          url:'http://127.0.0.1:8000/todos/' ,
          method:'POST',
          data:{
            'title':this.title,
            'is_completed':false,
          }
        })
        .then(response => {
          console.log("todo 생성완료",response)
          this.title=null
        })
        .catch(response => {
          console.log("요청 실패",response)
        })
      }
      console.log('createTodo')
    }
  }
}
</script>
