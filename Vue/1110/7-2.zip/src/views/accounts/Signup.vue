<template>
  <div></div>
</template>

<script>
// import axios from 'axios'

export default {
  name: 'Singup',
  data: function () {
    return {}
  },
  methods: {
    signup: function () {
      
    }
  }
}
</script>
