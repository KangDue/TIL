<template>
  <div class="about">
    <h1>중요 할일</h1>
  </div>
</template>

<script>
export default {
  name:'ImportantTodoPage',
}
</script>

<style>

</style>