<template>
  <div class="today">
    <h1>오늘 할일</h1>
  </div>
</template>

<script>
// @ is an alias to /src

export default {
  name: 'TodayTodoPage',
}
</script>
