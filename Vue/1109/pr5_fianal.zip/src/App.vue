<template>
  <div id="app">
    <div style="height:70vh;display:grid; grid-template-columns: 1fr 3fr;">
      <div class="inner" style="display:flex; flex-direction: column;">
        <router-link class="link" @click.native="selectPage('all')" 
          to="/">
          모든
        </router-link>
        <router-link class="link" to="/today">오늘</router-link>
        <router-link class="link" to="/important">중요</router-link>
      </div>
      <div class="inner">
        <router-view/>
      </div>
    </div>
    
  </div>
</template>

<script>
import { mapState } from 'vuex';
export default {
  name: 'App',
  data() {
    return {
    }
  },
  computed:{
    ...mapState('todo',{
      list: state => state.list
    }),
    pageObj() {
      console.log(this.$store.state.pageObj)
      return this.$store.state.pageObj
    }
  },
  methods:{
    selectPage(page) {
      this.$store.dispatch('selectPage',page)
    }
  }
}
</script>

<style>
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  color: #2c3e50;
}

.link {
  display:block;
  text-align: center;
  text-decoration: none;
}

/* 방문 전 */
/* a:link { color: black; text-decoration: none;} */

/* 방문 후 */
/* a:visited { color: black; text-decoration: none;} */

/* 마우스 올렸을 때 */
a:hover { color: lightgreen; text-decoration: none;} 
/* underline 밑줄,  */

.inner {
  border:1px solid black;
  border-radius:10px;
  margin-left:5px;
  margin-right:5px;
}

.link {
  font-size:3vh;
}

.router-link-exact-active {
  color:lightgreen;
  font-weight: bold;
}

.todo-item{
  border:1px solid black;
  border-radius: 5px;
  margin:5px;
  height: 5vh;
  display: flex;
  flex-direction: row;
  justify-content: space-between;
  align-items: center;
}

.todo-item:hover{
  cursor:pointer;
}

.board {
  display: flex;
  flex-direction: column;
  height: inherit;
}

.checked {
  text-decoration: line-through;
  color: blue;
}

.update-part {
  margin-top: 5px;
  margin-bottom: 5px;
  border: 1px solid gray;
  border-radius: 5px;
}
</style>
