<template>
  <div style="margin:5vh;">
    <h1>모든 할일</h1>
    <label for="todo-input"
     style="margin-left:5px; font-size:25px;" 
     @click="addTodo">+ </label>
    <input v-model="content"
     id="todo-input" 
     type="text" 
     style="height:3vh;" 
     placeholder="할 일을 작성해 주세요!" 
     @keyup.enter="addTodo">
    <hr>

    <div class="board">
      <div v-for="(todo,idx) in todoList" :key="idx">
        <TodoListItem :todo="todo"/>
        <TodoUpdateForm :todo="todo"/>
      </div>
    </div>
  </div>
</template>

<script>
import { mapState, } from 'vuex';
import TodoListItem from '@/components/TodoListItem.vue'
import TodoUpdateForm from '@/components/TodoUpdateForm.vue'
// mapActions
import _ from 'lodash'

function TodoForm(id,content,dueDateTime,isCompleted,isImportant,isOpen) {
  this.id = id
  this.content = content
  this.dueDateTime = dueDateTime
  this.isCompleted = isCompleted
  this.isImportant = isImportant
  this.isOpen=isOpen
}

export default {
    name:'AllTodoPage',
    components:{
      TodoListItem,
      TodoUpdateForm
    },
    data() {
      return {
        content:null
      }
    },
    computed:{
      ...mapState('todo',{
        todoList: state => state.list
      })
    },
    methods:{
      addTodo(){
        let now = new Date()
        let year = now.getFullYear()
        let month = now.getMonth()
        let date = now.getDate() 
        let ddt = year+'-'+month+'-'+date+'T00:00'
        let id = _.random(1000000000000,9999999999999)
        let todo = new TodoForm(id,this.content,ddt,false,false,false)
        this.$store.dispatch('todo/addTodo',todo)
        this.content=null
        // console.log(this.$store.state.todo)
      },
    },
}
</script>

<style>
</style>
