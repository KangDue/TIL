<template>
  <div>
    <div v-if="todo.isOpen" 
    style="background:#e6f4fa; padding:10px; border:1px solid gray; margin:5px;">
      <button class="update-part" @click="updateTodo(todo)">수정하기</button>
      <input class="update-part" type="text" style="display:block" v-model="content">
      <input class="update-part" type="datetime-local" 
      style="display:block" 
      v-model="dueDate">
    </div>
  </div>
</template>

<script>
export default {
  name:'TodoUpdateForm',
  props:{
    todo:Object
  },
  data(){
    return {
      content:this.todo.content,
      dueDate:this.todo.dueDateTime,
      }
  },
  methods:{
      updateTodo(todo){
        let info = {todo:todo,content:null, dueDateTime:null}
        info.content = this.content
        info.dueDateTime = this.dueDate
        this.content = null
        this.dueDate = null
        this.$store.dispatch('todo/updateTodo',info)
      },
  }

}
</script>

<style>

</style>