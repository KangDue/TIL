<template>
  <div>
    <div class="todo-item" @click="checkOpen(todo)">
      <div style="margin-left:10px;">
        <input class="form-check-input part"
          type="checkbox"
          :id="todo.id"
            @click="checkComplete(todo)" 
            :checked="todo.isCompleted">
        <label class="part" :for="todo.id" :class="{checked:todo.isCompleted}">{{ todo.content }}</label>
      </div>
      <div class="part" style="color:#FFD700; font-size:30px;" @click="checkImportant(todo)">
        <span v-if="todo.isImportant">★</span>
        <span v-else>☆</span>
      </div>
    </div>

    <!-- <div v-if="todo.isOpen" 
    style="background:#e6f4fa; padding:10px; border:1px solid gray; margin:5px;">
      <button class="update-part" @click="updateTodo(todo)">수정하기</button>
      <input class="update-part" type="text" style="display:block" v-model="content">
      <input class="update-part" type="datetime-local" 
      style="display:block" 
      v-model="dueDate">
    </div> -->
  </div>

</template>

<script>
export default {
  name:'TodoListItem',
  props:{
    todo:Object
  },
  data(){
    return {
      }
  },
  methods:{
      checkImportant(todo){
        this.$store.dispatch('todo/checkImportant',todo)
      },
      checkComplete(todo){
        this.$store.dispatch('todo/checkComplete',todo)
      },
      checkOpen(todo){
        
        this.$store.dispatch('todo/checkOpen',todo)
      },
  }
}
</script>

<style>
.part:hover {
  cursor:pointer;
}
</style>