const todo = {
  namespaced: true,
  state : () => {
    return {
      // todo 리스트 Array
      list: [
        // 개별 todo Object
        {
          id: 1638771553377,                // nowDateObj.getTime()
          content: 'Vue',                   // Todo 내용
          dueDateTime: '2021-12-09T00:00',  // 마감일
          isCompleted: false,               // 완료된 할 일
          isImportant: true,				        // 중요 할 일
          isOpen:false,
        },
        {
          id: 1638771553378,
          content: 'Vue Router',
          dueDateTime: '2021-12-10T00:00',
          isCompleted: false,
          isImportant: true,
          isOpen:false,
        },
        {
          id: 16387715533779,
          content: 'Vuex',
          dueDateTime: '2021-12-11T00:00',
          isCompleted: true,
          isImportant: false,
          isOpen:false,
        },
      ],
    }
  },
  mutations: {
    ADD_TODO(state,todo) {
      state.list.push(todo)
    },
    CHECK_IMPORTANT(state,todo){
      state.list.forEach((val) => {
        if (val===todo){
          val.isImportant = !val.isImportant 
        }
      })
    },
    CHECK_COMPLETE(state,todo){
      state.list.forEach((val) => {
        if (val===todo){
          val.isCompleted = !val.isCompleted 
        }
      })
    },
    CHECK_OPEN(state,todo){
      state.list.forEach((val) => {
        if (val===todo){
          val.isOpen = !val.isOpen 
        }
      })
    },
    UPDATE_TODO(state,info){
      state.list.forEach((val) => {
        if (val===info.todo){
          val.content = info.content
          val.dueDateTime = info.dueDateTime
        }
      })
    }
  },
  actions: {
    addTodo(context,todo) {
      context.commit("ADD_TODO",todo)
    },
    checkImportant(context,todo) {
      context.commit('CHECK_IMPORTANT',todo)
    },
    checkComplete(context,todo) {
      context.commit('CHECK_COMPLETE',todo)
    },
    checkOpen(context,todo) {
      context.commit('CHECK_OPEN',todo)
    },
    updateTodo(context,info){
      context.commit('UPDATE_TODO',info)
    },
  },
}

export default todo