import Vue from 'vue'
import Vuex from 'vuex'
import todo from '@/store/modules/todo'
Vue.use(Vuex)

export default new Vuex.Store({
  state: {
    pageObj:{
      "all":false,
      "today":false,
      "important":false,
    }
  },
  getters: {
  },
  mutations: {
    SELECT_PAGE(state,page){
      state.pageObj[page] = !state.pageObj[page]
    }
  },
  actions: {
    selectPage(context,page){
      context.commit('SELECT_PAGE',page)
    }
  },
  modules: {
    todo:todo,
  }
})
