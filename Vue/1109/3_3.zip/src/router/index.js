import Vue from 'vue'
import VueRouter from 'vue-router'
import NoColor from '../views/NoColor.vue'
import notFound from '../views/404.vue'
import SsafLeaf from '../views/SsafLeaf.vue'
import SsafLing from '../views/SsafLing.vue'
import SsafLower from '../views/SsafLower.vue'
import HomeView from '../views/HomeView.vue'
Vue.use(VueRouter)

const limits = {
  'nocolor':0,
  'ling':1,
  'leaf':2,
  'flower':3,
}

const routes = [
  {
    path: '/',
    name: 'home',
    component: HomeView,
  },
  {
    path: '/notfound',
    name: 'notfound',
    component: notFound
  },
  {
    path: '/nocolor',
    name: 'nocolor',
    component: NoColor,
  },
  {
    path: '/leaf',
    name: 'leaf',
    component: SsafLeaf,
  },
  {
    path: '/ling',
    name: 'ling',
    component: SsafLing,
  },
  {
    path: '/flower',
    name: 'flower',
    component: SsafLower,
  },
]

const router = new VueRouter({
  mode: 'history',
  base: process.env.BASE_URL,
  routes
})

router.beforeEach((to,from,next) => {
	//to는 이동하려고 선택한 페이지, from은 현재 페이지 정보.
  let a
  let b
  for (let i in limits){
    if (i === to.name){a = true }
    if (i === from.name){b = true}
  }
  console.log(parseInt(a+b),a,b)
  if (a&&b){ // 이름 존재시
    if (limits[to.name] < limits[from.name]){
      alert("이전 진화 단계로 돌아갈 수 없습니다.")
    }
    else {
      next()
    }
    //통과 = 존재 안함
  }
  else if (a && !b && (to.name !== 'nocolor' )) {
    alert('올바른 경로가 아닙니다.')
    next({name:'home'})
  }
  else{
    next()
  }
  
})
export default router
