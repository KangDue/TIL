<template>
  <div id="app">
    <h1>캐릭터 진화 단계 가이드</h1>
    <div style="display:flex; 
    flex-direction:row; 
    justify-content:center;">
      <div class='initail-box' 
      @click="goHome">
        Home
      </div>
      <div class='initail-box' 
      @click="goStart">Start</div>
    </div>
    <router-view/>
  </div>
</template>

<script>
export default {
    name:'SsafLower',
    methods:{
      goHome(){
        this.$router.push({name:'home'})
      },
      goStart(){
        this.$router.push({name:'nocolor'})
      }
    }
}
</script>

<style>
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
}

nav {
  padding: 30px;
}

nav a {
  font-weight: bold;
  color: #2c3e50;
}

nav a.router-link-exact-active {
  color: #42b983;
}

.initail-box {
  border:1px solid orange;
  margin-left:10px;
  margin-right:10px;
  height:5vh;
  width:10vw;
  display : flex;
  justify-content : center;
  align-items : center;
}

.game {
  width:50%;
  height:50%;
  display: block;
}
</style>
