<template>
  <div>
    <h3>시작</h3>
    <div style="display:flex; 
    flex-direction:row; 
    justify-content:space-between; 
    align-items: center;
    margin-left:20px;
    margin-right:20px;">
        <button @click="goBefore"> &lt;</button>
        <img class="game" src="data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wBDAAkGBwgHBgkIBwgKCgkLDRYPDQwMDRsUFRAWIB0iIiAdHx8kKDQsJCYxJx8fLT0tMTU3Ojo6Iys/RD84QzQ5Ojf/2wBDAQoKCg0MDRoPDxo3JR8lNzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzf/wAARCAA5AEADASIAAhEBAxEB/8QAGAABAQEBAQAAAAAAAAAAAAAAAAYHBQT/xAAnEAABBAIBAgYDAQAAAAAAAAABAAIDBQQRMRIhBhMiQVFhFSNCkf/EABcBAQEBAQAAAAAAAAAAAAAAAAACAwH/xAAaEQADAQEBAQAAAAAAAAAAAAAAAQIDETEh/9oADAMBAAIRAxEAPwDcUREAREQBERAEREAREQBTd94lOJlHDrjA6dhPnPl7tjIYXhvSCCSQB7jXUOeF0/Edi6oos6wY0Pkghc5jTwXa9IP1vSk6iqpYMqatzmuy7aOJmRlTTg9JMjj3H87LgftY7W0uT6a5Sm+sq6O3ht8UvYAyePQmhDuroJGxo+4IOwf9AIIHSWeYUuBW3cNjSukZjnP/ABedA4O6S9x00t38PLe/fkga7rQ1WdOl99J0lS/ngREWhAREQHltcCG0rMqvyd+TkxOif08gEa2PtQ77i6pGNwb+jss50XpjzauMysnA4c5oO2n6Pvx8rQkUXmrNM9HBFVMNr4jssPNsMCatqcJ/nQwZJ/dkSAaaXjlobsnR77AVqiLsSpXEcu3T6ERFRAREQBERAEREAREQH//Z">
        <button @click="goNext"> &gt;</button>
    </div>
    
  </div>
</template>

<script>
export default {
    name:'NoColor',
    methods:{
        goBefore() {
            alert("이전 진화 단계로 돌아갈 수 없습니다.")
        },
        goNext() {
            this.$router.push({name:'ling'})
        }
    }
}
</script>

<style>
button {
    background: black;
    color:white;
    font-weight: bolder;
    border-radius: 15px;
    height:30px;
    width:30px;
}
</style>