<template>
  <div>
    <h3>1단계</h3>
    <div style="display:flex; 
    flex-direction:row; 
    justify-content:space-between; 
    align-items: center;
    margin-left:20px;
    margin-right:20px;">
        <button @click="goBefore"> &lt;</button>
    <img class="game" src="data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wBDAAkGBwgHBgkIBwgKCgkLDRYPDQwMDRsUFRAWIB0iIiAdHx8kKDQsJCYxJx8fLT0tMTU3Ojo6Iys/RD84QzQ5Ojf/2wBDAQoKCg0MDRoPDxo3JR8lNzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzf/wAARCAA5AEADASIAAhEBAxEB/8QAGQABAQADAQAAAAAAAAAAAAAAAAYCBQcD/8QALxAAAQQCAQIDBAsAAAAAAAAAAQACAwQFERIhMQYVYRMUFiImMkFCUVJxgYKR8P/EABgBAQEBAQEAAAAAAAAAAAAAAAACAwEE/8QAIhEAAgICAgAHAAAAAAAAAAAAAAECEQMSBDEhMkFhgZGh/9oADAMBAAIRAxEAPwDuKIiAIiIAiIgCIiAIiIB+ih83ezWLsMYyzHLceC4hspI4AElxaRxb0a7j6j7wDiq3L34sVi7V+cEx1onSFo7u0N6Hqeyisbgjfkmly+Wk80l1PPVrSNBhDwQOQOz2HEeg1s62vNyY7VTdr3a+67LhiU/N0b/wx79MBafbElV7TtjpHPdy/kAW6/w+1UKgsP8AR/OxmvfF3G3pxUnPMOdDOG6Zy103oBvYd27+qFequPFRxqKv5bf6zkoKDpdBERbkhERAa7xDjTmMHexzZBG+xC5jHkbDXa+U/sdFQvxHQZZd5kK2Hz7WNjuNtxEGRrd64vHdu9ka3tdLXhap1bjWtt1oZ2tOwJYw4D+1nkx7+priy6PxVkDh31PEOSq18DWZ5dXuC/kb8cPs457DeoDfzOLwCfwAHXqN9FWMbGRsDI2taxo0GtGgFkuwhqqJnPZ9BERWQEREAREQBERAEREB/9k=">
    <button @click="goNext"> &gt;</button>
    </div>
  </div>

  
</template>

<script>
export default {
    name:'SsafLing',
    methods:{
        goBefore() {
            alert("이전 진화 단계로 돌아갈 수 없습니다.")
        },
        goNext() {
            this.$router.push({name:'leaf'})
        }
    }
}
</script>

<style>

</style>