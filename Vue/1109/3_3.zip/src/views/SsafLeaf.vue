<template>
  <div>
    <h3>2단계</h3>
    <div style="display:flex; 
    flex-direction:row; 
    justify-content:space-between; 
    align-items: center;
    margin-left:20px;
    margin-right:20px;">
        <button @click="goBefore"> &lt;</button>
    <img class="game" src="data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wBDAAkGBwgHBgkIBwgKCgkLDRYPDQwMDRsUFRAWIB0iIiAdHx8kKDQsJCYxJx8fLT0tMTU3Ojo6Iys/RD84QzQ5Ojf/2wBDAQoKCg0MDRoPDxo3JR8lNzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzf/wAARCAA5AEADASIAAhEBAxEB/8QAGgABAAIDAQAAAAAAAAAAAAAAAAYHAgMEBf/EACgQAAEFAAAEBgIDAAAAAAAAAAEAAgMEEQUSIUEGExQxUWEiUiMycf/EABgBAQEBAQEAAAAAAAAAAAAAAAADAgQB/8QAHhEAAgICAwEBAAAAAAAAAAAAAAMBAhEhBBIxE6H/2gAMAwEAAhEDEQA/ALxREQBERAEREAREQBERAYyPZGxz5HNYxoJc5xwADuSobP4j4nLbnFKSt6IvJhmdCeYgds5uoJ3r8Dp/YFvZ43tmJlWu8/wOD5pB+/IWgNI7jXb/AK0LClS4c3mgsSxy3WAGZnm55e505QfsdT76osZicQd3HUutPoyM58g3+HeO2bl2avxR8EUjwPTRsaQHYXcwDiTpwA50Ob95JFAOMV6QhMtGw18TZvKkbHJzGGQfkCD7ggjfkHMxTHgduS9wepZmzzZIgZC0YC72JH1ur1d+2pMclNYiGL8n8O5ERVOQIiIDxfFPBDxmkBC5rbMYPIXezgc1p+ASGnfodtUXZZvsrsqcUinp2muLjNFM0c+DPzDg4aexGjeuhWEig5Ms3WcSWryGVp0rOs5K6mqcY8RzV4aVf0tEBpkszSc79AwF37OwnoNHyR0U+o1YqNOCpXBEUEbY2AnTgGDT3W9FpS+kbnMhj2MpWlvICIiqRCIiAIiIAiIgCIiA/9k=">
    <button @click="goNext"> &gt;</button>
    </div>
  </div>
</template>

<script>
export default {
    name:'SsafLeaf',
    methods:{
        goBefore() {
            alert("이전 진화 단계로 돌아갈 수 없습니다.")
        },
        goNext() {
            this.$router.push({name:'flower'})
        }
    }
}
</script>

<style>

</style>