<template>
  <div>
    <h3>3단계</h3>
    <div style="display:flex; 
    flex-direction:row; 
    justify-content:space-between; 
    align-items: center;
    margin-left:20px;
    margin-right:20px;">
        <button @click="goBefore"> &lt;</button>
    <img class="game" src="data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wBDAAkGBwgHBgkIBwgKCgkLDRYPDQwMDRsUFRAWIB0iIiAdHx8kKDQsJCYxJx8fLT0tMTU3Ojo6Iys/RD84QzQ5Ojf/2wBDAQoKCg0MDRoPDxo3JR8lNzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzf/wAARCAA5AEADASIAAhEBAxEB/8QAGQABAAIDAAAAAAAAAAAAAAAAAAUGAwQH/8QALBAAAgEDAwMCBAcAAAAAAAAAAQIDAAQRBRIhEzFBBjIUIlGBM1JhYnHB0f/EABkBAQEAAwEAAAAAAAAAAAAAAAAEAgMFAf/EACQRAAICAQIFBQAAAAAAAAAAAAABAgMEERITMVFh8CFBcaHR/9oADAMBAAIRAxEAPwDuNKUoBSlKAUpSgFKUoBSlKA1NR1Kz02ISXs3TDHCgKWZv4UAk/YVQb7XhrcTSTzboFkyLYHaEwTtyPcWGBnPZgMAGsmtSdDVL93kR5Y5W5uGJyvuCecD5sAD+6mdHex067utKtrOSKSJUlnu+lhJ2bj355YYxg9hjHHaWyxttL2OrVVXjwjZJbnLl0XnnfU0P1YttfNp+pXRmjCZSUKZGjIIG1igOQQeCfynJOeLrFIk0SSxOrxuoZXU5DA9iD5Fc/v5bO8e7vra0NlPDdtZzvdxdPq4AIdfqM/KG88/piX9EfjX2xmEWyMiPJ2hiXLEDsCeM/Ws6rG3tZryKa5VceHp1X4WulKVvOcKx3DvFBJJHEZXRCyxqQC5A4Az9ayUoDlGqWZ1K8jk1WG5Yz7hcFopUDPgYBVsKoCgqAR4GSSalbjWLaGziGqJcjEm1ZreT53PCjeBjk5HOMeeKvV9ZwahbNbXaF4mKkgOVOQQRyCD3AqOX0vowfc9o0vBG2aaSRef2sxH+VHHFlFabm+7LsfJhClV2avTloVHVprbUYI0ntytlCiyKpkyzFQQC5HOQO2DnPJ57bnof4uxmt7Zbe6Mc4JuepG4CMEGGLMPdwFIzzkEAYqxR+l9JjKlYJjtIIDXUpHBz2Lc/fv5qZr1Yz3Rlua0+/kwy742xjCvVJClKVWSClKUApSlAKUpQClKUB//Z">
    <button @click="goNext"> &gt;</button>
    </div>
  </div>
</template>

<script>
export default {
    name:'SsafLower',
    methods:{
        goBefore() {
            alert("이전 진화 단계로 돌아갈 수 없습니다.")
        },
        goNext() {
            this.$router.push({name:'notfound'})
        }
    }
}
</script>

<style>

</style>