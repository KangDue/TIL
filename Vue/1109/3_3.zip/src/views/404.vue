<template>
  <div>
    <h2>찾으시려는 페이지가 존재하지 않습니다!</h2>
    <img src="../assets/noResult.png" alt="">
  </div>
</template>

<script>
export default {
    name:'notFound',
}
</script>

<style>

</style>