<template>
  <div>
    <h1>About</h1>
    <h2>첫 번째 박스</h2>
    <div class="global">
      <div class="box scoped-box"></div>
    </div>
    <h2>두 번째 박스</h2>
    <div class="global">
      <div class="box scoped-box"></div>
    </div>
  </div>
</template>

<script>
export default {
  name:'AboutView',
}
</script>

<!-- scoped로 style 적용을 해당 .vue 파일로 한정시킨다. -->
<style scoped> 
.scoped-box {
  background:pink;
}
</style>
