<template>
  <div>
    <h1>점심메뉴</h1>
    <button @click="pickMenu">Pick Lunch</button>
    <div style="margin-top:10px; 
    margin-bottom:50px;">{{menu}}</div>
    <h2>로또를 뽑아보자</h2>
    <button @click="goLotto">Pick Lotto</button>
  </div>
</template>

<script>
import _ from 'lodash'
export default {
    name:'TheLunch',
    data(){
        return {
            menu:null,
            menuList:['국밥','피자','라면','샌드위치']
        }
    },
    methods: {
        pickMenu(){
            this.menu = _.sample(this.menuList) 
        },
        goLotto(){
            this.$router.push({name:'lotto'})
        }
    }
}
</script>

<style>

</style>