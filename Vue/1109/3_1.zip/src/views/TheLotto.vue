<template>
  <div>
    <h1>로또</h1>
    <button @click="getNums">Get Lucky Numbers</button>
    <div style="margin-top:20px;">{{ nums }}</div>
  </div>
</template>

<script>
import _ from 'lodash'
export default {
    name:'TheLotto',
    data(){
        return {
            nums:null
        }
    },
    methods:{
        getNums(){
            this.nums = _.sampleSize(_.range(1,45,1),6)
        }
    }
}
</script>

<style>

</style>