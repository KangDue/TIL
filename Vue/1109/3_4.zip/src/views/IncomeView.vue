<template>
    <div>
    <h1>소득세 계산기</h1>
    <div>
      <label for="year">연봉 입력 (만원): </label>
      <input name="year" type="text" v-model.number="totEarn" @keyup="update">
    </div>
    <div>
      <label for="hal">세액감면액 (만원): </label>
      <input name="hal" type="text" v-model.number="taxSub" @keyup="update">
    </div>
    <hr>
    <h2>종합소득금액 : {{ totEarn }} 만원</h2>
    <h2>종합소득공제 : (-) {{ totSub }} 만원</h2>
    <h2>과세표준 : {{ addTaxStandard }} 만원</h2>
    <hr>
    <TaxrateView :taxSub="taxSub" 
    :addTaxStandard="addTaxStandard"/>
  </div>
</template>

<script>
import TaxrateView from '@/views/TaxrateView.vue'
export default {
  name:'IncomeView',
  components:{
    TaxrateView
  },
  data() {
    return {
      totEarn:null, // 종합 소득
      totSub:150, // 종합 소득 공제
      taxSub:null,// 세엑 감면
    }
  },
  computed:{
    addTaxStandard() {// 과세 표준
      let result = this.totEarn - this.totSub
      return (result)*(result>=150)
    }
  },
  methods:{
    update() {
      this.$forceUpdate()
    }
  }

}
</script>

<style>

</style>