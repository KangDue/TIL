<template>
    <div>
    <h1>소득세 계산기</h1>
    <div>
      <label for="year">연봉 입력 (만원): </label>
      <input name="year" type="text">
    </div>
    <div>
      <label for="hal">세액감면액 (만원)</label>
      <input name="hal" type="text">
    </div>
  </div>
</template>

<script>
export default {
  name:'IncomeView',
}
</script>

<style>

</style>