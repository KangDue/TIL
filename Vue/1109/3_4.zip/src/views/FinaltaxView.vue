<template>
  <div>
    <h2>결정세액 : {{final}} 만원</h2>
  </div>
</template>

<script>
export default {
  name:'FinaltaxView',
  props:{
    final:{
      type:Number,
      default:null,
    }
  }
}
</script>

<style>

</style>