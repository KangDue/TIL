<template>
  <div>
    <h1>최종 세금</h1>
  </div>
</template>

<script>
export default {
  name:'FinaltaxView',
}
</script>

<style>

</style>