<template>
    <div>
    <h1>세금비율</h1>
  </div>
</template>

<script>
export default {
  name:'TaxrateView',
  props:{
    standard:Number,
    minus:Number,
  },
  methods:{
    cal() {
      if (this.standard <= 1200){ return 0.06 }
      else if (this.standard <= 4600) { return 0.15 }
      else if (this.standard <= 8800) { return 0.24 }
      else if (this.standard <= 15000) { return 0.35 }
      else if (this.standard <= 30000) { return 0.38 }
      else if (this.standard <= 50000) { return 0.40 }
      else if (this.standard <= 100000) { return 0.42 }
      else { return 0.45 }
    }

  }
}
</script>

<style>

</style>