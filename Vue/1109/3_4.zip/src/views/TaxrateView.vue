<template>
  <div>
    <h2>산출세액 : {{ result }} 만원</h2>
    <h2>세액감면 : (-) {{taxSub}} 만원</h2>
    <hr>
    <FinaltaxView :final="final"/>
  </div>
</template>

<script>
import FinaltaxView from '@/views/FinaltaxView.vue'
export default {
  name:'TaxrateView',
  components:{
    FinaltaxView
  },
  props:{
    taxSub:{
      type:Number,
      default:null //처음에 없던 값은 추적하지 않으므로 기본값 지정해줘야함.
    }, // 세엑 감면액
    addTaxStandard:{
      type:Number,
      default:null
    }, // 과세표준
  },
  data() {
    return {
      go:1
    }
  },
  computed:{
    final() {
      return this.result-this.taxSub
    },
    result() {
        let rate // 세율
        let accSub // 누진공제
        if (this.addTaxStandardn) {
          return 0
        }
        if (this.addTaxStandard <= 1200){ 
          rate = 0.06
          accSub = 0
        }
        else if (this.addTaxStandard <= 4600) { 
          rate = 0.15
          accSub = 108
          }
        else if (this.addTaxStandard <= 8800) { 
          rate = 0.24
          accSub = 522
          }
        else if (this.addTaxStandard <= 15000) { 
          rate = 0.35
          accSub = 1490
          }
        else if (this.addTaxStandard <= 30000) { 
          rate = 0.38
          accSub = 1940
          }
        else if (this.addTaxStandard <= 50000) { 
          rate = 0.40
          accSub = 2540
          }
        else if (this.addTaxStandard <= 100000) { 
          rate = 0.42
          accSub = 3540
          }
        else if (this.addTaxStandard > 100000) { 
          rate = 0.45
          accSub = 6540
          }
        // this.final = Math.round(rate*this.addTaxStandard)-accSub
        return Math.round(rate*this.addTaxStandard)-accSub
      }
    },
  methods:{
  },
}
</script>

<style>

</style>