import Vue from 'vue'
import VueRouter from 'vue-router'
import FinaltaxView from '../views/FinaltaxView.vue'
// import IncomeView from '../views/IncomeView.vue'
import TaxrateView from '../views/TaxrateView.vue'

Vue.use(VueRouter)

const routes = [
  {
    path: '/final',
    name: 'FinaltaxView',
    component: FinaltaxView
  },
  // {
  //   path: '/income',
  //   name: 'income',
  //   component: IncomeView
  // },
  {
    path: '/rate',
    name: 'rate',
    component: TaxrateView
  },
]

const router = new VueRouter({
  mode: 'history',
  base: process.env.BASE_URL,
  routes
})

export default router
