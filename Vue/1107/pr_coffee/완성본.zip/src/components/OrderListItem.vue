<template>
  <li>
    <div class="orders">
      <div>
        <div style="display:flex;">
          <img class="inner" :src="order.menu.image" alt="" style="height:40px; width:40px; display:block;">
            <div style="display:grid; grid-template-row:1fr 1fr;">
              <div class="inner">{{ order.menu.title }}</div>
              <div class="inner">{{ order.size.name }}</div>
            </div>
        </div>
      </div>
      <div>
        <div class="inner">{{ totalPrice }}원</div>
        <div>
          <span v-for="(type,idx) in optKeyAndVal" :key="idx">{{idx}} {{type}}회|</span>
        </div>
      </div>
    </div>
    <hr>
  </li>
  
</template>

<script>
export default {
  name: 'OrderListItem',
  props: {
    order: Object,
  },
  computed: {
    totalPrice: function () { 
      let optionPrice = 0
      this.order.option.forEach((opt)=>{
        optionPrice += opt.price*opt.count
      })

      return this.order.menu.price + this.order.size.price 
      + optionPrice
    },
    optKeyAndVal() {
      let temp = {}
      this.$store.state.optionList.forEach(
        (val) => {temp[val.type]=0}
      )

      this.order.option.forEach((opt)=>{
        temp[opt.type] = opt.count
      })
      console.log(temp)
      return temp
    }
  },
}
</script>

<style>
.orders {
  display:flex;
  flex-direction: row;
  justify-content: space-between;
  height:70px;
  align-items: center;
}
</style>