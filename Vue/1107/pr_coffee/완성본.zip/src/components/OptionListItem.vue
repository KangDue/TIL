<template>
  <div>
    <li>
      <div class='plate2'>
        <div class="inner">{{ option.type }}</div>
        <div class="inner" style="display:flex; flex-direction: row;">
          <button class='opbtn' @click="decrease">-</button>
          {{ option.count }}
          <button class='opbtn' @click="increase">+</button>
        </div>
      </div>
    </li>
  </div>
</template>

<script>
export default {
  name: 'OptionListItem',
  props: {
    option: Object,
  },
  methods: {
    increase() {
      this.$store.dispatch('increase',this.option)
    },
    decrease() {
      this.$store.dispatch('decrease',this.option)
    },
  },
}
</script>

<style>
.opbtn {
  width:30px;
  height:30px;
  border-radius: 15px;
  margin-left:5px;
  margin-right:5px;
  border: 1px solid black;
  cursor: pointer;
}

.plate2{
  display:flex;
  flex-direction:row;
  justify-content: space-between;
  align-items: center;
  border-radius: 10px;
  border:2px solid black;
  height:60px;
}
</style>