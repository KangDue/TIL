<template>
  <div>
    <ul class="option-list">
      <h1>3. 옵션을 고르세요.</h1>
      <OptionListItem v-for="(option,idx) in optionList"
     :key="idx" 
     :option="option"/>/>
    </ul>
  </div>
</template>

<script>
import OptionListItem from '@/components/OptionListItem';
export default {
  name: 'OptionList',
  components: {
    OptionListItem,
  },
  computed: {
    optionList: function () {
      return this.$store.state.optionList
    },
  },
  methods: {
    increase: function () {
    },
    decrease: function () {
    },
  },
}
</script>

<style>
.option-list{
  margin:10px;
  background: white;
  border-radius: 10px;
}
</style>