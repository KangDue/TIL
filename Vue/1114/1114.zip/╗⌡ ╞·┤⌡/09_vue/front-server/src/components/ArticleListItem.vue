<template>
  <div>
    <h5>PK: {{ article.id }}</h5>
    <p>제목: {{ article.title }}</p>
    <p>내용: {{ article.content }}</p>
    <hr> 
  </div>
</template>

<script>
export default {
  name: 'ArticleListItem',
  props:{
    article:Object,
  }
}
</script>

<style>

</style>
