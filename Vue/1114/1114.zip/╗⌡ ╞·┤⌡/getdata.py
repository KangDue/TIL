from urllib.request import urlopen
from bs4 import BeautifulSoup

source = urlopen("http://naver.com")
html = BeautifulSoup(source,"html.parser")
atag= html.findAll
print(html)