from django.shortcuts import render
from .models import *

def index(request):
    team = Team.objects.all()
    return render(request, 'team/index.html')