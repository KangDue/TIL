1. sign up, view 고치기
- login -> auth_login

2. 게시글에서 profile 클릭시 정상작동 안하는 오류
profile.html상에서 아래와 같은 글로 되돌아가는 코드에서
detail의 인자 article.pk가 누락되어 있었음.
<a href="{% url 'articles:detail' article.pk %}">{{ article.title }}</a>

3. article list가 정상 출력되도록 하기
render -> redirect로

4. article update
update시 새로운 게시글이 작성됨.
form = ArticleForm(instance=article,data=request.POST)
instance 인자 추가

5. 
삭제를 눌러도 삭제가 안됨.
템플릿을 수정하자 (403 포비든이 뜬다.)
csrf 토큰 추가

6. detail에서
댓글목록을 보여주가
comments = article.comment_set.all() 를
context에 추가.
template은 이미 완성되어있음.

7. 좋아요 오류뜸.
'Article' object has no attribute 'like_articles'
article.like_users.remove(request.user) 로 수정
articles로 되어있었음.